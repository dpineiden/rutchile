# rutchile
Clase y método para verificar RUT Chileno (en python)

Entre las características:
	-Verificar que el dato ingresado tiene una estructura de rut: XX XXX XXX -X 
	-Verificar que el digito verificador (ultimo dígito) corresponda 
	-Entrega el nombre en palabras del rut